import { useEffect, useMemo, useState } from "react";

const doctors = [
  {
    id: "maya-patel",
    name: "Dr. Maya Patel",
    specialty: "Cardiologist",
    experience: "12 years experience",
    rating: "4.98",
    reviews: "248 reviews",
    fee: "$80",
    image:
      "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=720&q=85",
    color: "lavender",
    available: "Today, 2:30 PM",
  },
  {
    id: "james-wilson",
    name: "Dr. James Wilson",
    specialty: "Neurologist",
    experience: "9 years experience",
    rating: "4.96",
    reviews: "186 reviews",
    fee: "$95",
    image:
      "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=720&q=85",
    color: "blue",
    available: "Today, 4:00 PM",
  },
  {
    id: "elena-rodriguez",
    name: "Dr. Elena Rodriguez",
    specialty: "Dermatologist",
    experience: "8 years experience",
    rating: "4.93",
    reviews: "172 reviews",
    fee: "$75",
    image:
      "https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=720&q=85",
    color: "peach",
    available: "Tomorrow, 9:15 AM",
  },
  {
    id: "noah-kim",
    name: "Dr. Noah Kim",
    specialty: "Pediatrician",
    experience: "11 years experience",
    rating: "4.99",
    reviews: "312 reviews",
    fee: "$70",
    image:
      "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=720&q=85",
    color: "mint",
    available: "Tomorrow, 11:30 AM",
  },
  {
    id: "sophia-chen",
    name: "Dr. Sophia Chen",
    specialty: "Dentist",
    experience: "10 years experience",
    rating: "4.97",
    reviews: "204 reviews",
    fee: "$65",
    image:
      "https://images.unsplash.com/photo-1606811971618-4486d14f3f99?auto=format&fit=crop&w=720&q=85",
    color: "mint",
    available: "Today, 3:15 PM",
  },
  {
    id: "oliver-brooks",
    name: "Dr. Oliver Brooks",
    specialty: "Orthopedic",
    experience: "14 years experience",
    rating: "4.95",
    reviews: "231 reviews",
    fee: "$90",
    image:
      "https://images.unsplash.com/photo-1622902046580-2b47f47f5471?auto=format&fit=crop&w=720&q=85",
    color: "blue",
    available: "Tomorrow, 10:00 AM",
  },
];

const specialties = [
  { name: "Cardiology", icon: "♡", color: "coral", detail: "Heart & circulation" },
  { name: "Neurology", icon: "✳", color: "purple", detail: "Brain & nerves" },
  { name: "Dental care", icon: "✦", color: "blue", detail: "Teeth & gums" },
  { name: "Pediatrics", icon: "⌣", color: "yellow", detail: "Care for little ones" },
  { name: "Dermatology", icon: "◉", color: "pink", detail: "Skin & hair" },
  { name: "Orthopedics", icon: "⌁", color: "green", detail: "Bones & joints" },
];

const specialtyDoctor = {
  Cardiology: "Cardiologist",
  Neurology: "Neurologist",
  "Dental care": "Dentist",
  Pediatrics: "Pediatrician",
  Dermatology: "Dermatologist",
  Orthopedics: "Orthopedic",
};

const Icon = ({ name, size = 20 }) => {
  const paths = {
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    pin: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    arrow: <><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 11h18" /></>,
    close: <><path d="m18 6-12 12M6 6l12 12" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    star: <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z" />,
    phone: <><path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3.1 5.2 2 2 0 0 1 5.1 3h3a2 2 0 0 1 2 1.7l.5 2.8a2 2 0 0 1-.6 1.7L8.1 11a16 16 0 0 0 4.9 4.9l1.8-1.9a2 2 0 0 1 1.7-.6l2.8.5a2 2 0 0 1 1.7 2Z" /></>,
  };
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
};

function AppointmentModal({ doctor, onClose }) {
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  function handleSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const appointment = {
      id: crypto.randomUUID(),
      doctorId: String(formData.get("doctor")),
      patientName: String(formData.get("name")).trim(),
      email: String(formData.get("email")).trim(),
      date: String(formData.get("date")),
      time: String(formData.get("time")),
      reason: String(formData.get("reason")).trim(),
      createdAt: new Date().toISOString(),
    };

    try {
      const saved = JSON.parse(
        window.localStorage.getItem("careplus-appointments") || "[]",
      );
      if (!Array.isArray(saved)) {
        throw new Error("Saved appointment data is not in the expected format.");
      }
      window.localStorage.setItem(
        "careplus-appointments",
        JSON.stringify([appointment, ...saved]),
      );
      setError("");
      setSubmitted(true);
    } catch (storageError) {
      setError(
        storageError instanceof Error
          ? storageError.message
          : "Your appointment could not be saved. Please try again.",
      );
    }
  }

  return (
    <div
      className="modal-backdrop"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="booking-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="booking-title"
      >
        <button className="modal-close" onClick={onClose} aria-label="Close booking">
          <Icon name="close" />
        </button>
        {submitted ? (
          <div className="booking-success">
            <div className="success-check"><Icon name="check" size={28} /></div>
            <span className="eyebrow">YOU’RE ALL SET</span>
            <h2 id="booking-title">Appointment requested!</h2>
            <p>Your visit is saved on this device. We look forward to seeing you.</p>
            <button className="button button-primary button-wide" onClick={onClose}>
              Done <Icon name="arrow" size={18} />
            </button>
          </div>
        ) : (
          <>
            <span className="eyebrow">TAKE THE FIRST STEP</span>
            <h2 id="booking-title">Book an appointment</h2>
            <p className="modal-intro">Choose a doctor and a time that works for you.</p>
            <form className="booking-form" onSubmit={handleSubmit}>
              <label>
                Choose a doctor
                <select name="doctor" defaultValue={doctor?.id || doctors[0].id}>
                  {doctors.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} · {item.specialty}
                    </option>
                  ))}
                </select>
              </label>
              <div className="form-row">
                <label>
                  Your name
                  <input name="name" autoComplete="name" placeholder="e.g. Alex Morgan" required />
                </label>
                <label>
                  Email address
                  <input name="email" type="email" autoComplete="email" placeholder="you@example.com" required />
                </label>
              </div>
              <div className="form-row">
                <label>
                  Preferred date
                  <input name="date" type="date" min={new Date().toISOString().slice(0, 10)} required />
                </label>
                <label>
                  Preferred time
                  <select name="time" defaultValue="" required>
                    <option value="" disabled>Select a time</option>
                    <option>9:00 AM</option>
                    <option>10:30 AM</option>
                    <option>1:00 PM</option>
                    <option>2:30 PM</option>
                    <option>4:00 PM</option>
                  </select>
                </label>
              </div>
              <label>
                What brings you in? <span className="optional">(optional)</span>
                <textarea name="reason" placeholder="A short note for your doctor" rows="3" />
              </label>
              {error && <p className="form-error" role="alert">{error}</p>}
              <button className="button button-primary button-wide" type="submit">
                Confirm appointment <Icon name="arrow" size={18} />
              </button>
              <p className="privacy-note">Your health information stays private and secure.</p>
            </form>
          </>
        )}
      </section>
    </div>
  );
}

export default function App() {
  const [apiStatus, setApiStatus] = useState("checking");
  const [selectedSpecialty, setSelectedSpecialty] = useState("All doctors");
  const [search, setSearch] = useState("");
  const [bookingDoctor, setBookingDoctor] = useState(null);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    let active = true;
    fetch("/api/health")
      .then((response) => {
        if (!response.ok) throw new Error(`API returned ${response.status}`);
        return response.json();
      })
      .then((data) => {
        if (active && data.status === "ok") setApiStatus("connected");
      })
      .catch(() => {
        if (active) setApiStatus("error");
      });
    return () => {
      active = false;
    };
  }, []);

  const visibleDoctors = useMemo(() => {
    const query = search.trim().toLowerCase();
    return doctors.filter((doctor) => {
      const matchesSpecialty =
        selectedSpecialty === "All doctors" ||
        doctor.specialty.toLowerCase().includes(selectedSpecialty.toLowerCase());
      const matchesQuery =
        !query ||
        `${doctor.name} ${doctor.specialty}`.toLowerCase().includes(query);
      return matchesSpecialty && matchesQuery;
    });
  }, [search, selectedSpecialty]);

  function showDoctors(specialty = "All doctors") {
    setSelectedSpecialty(specialty);
    document.getElementById("doctors")?.scrollIntoView({ behavior: "smooth" });
  }

  function openBooking(doctor = null) {
    setBookingDoctor(doctor);
    setBookingOpen(true);
  }

  function closeBooking() {
    setBookingOpen(false);
    setBookingDoctor(null);
  }

  function handleSearch(event) {
    event.preventDefault();
    showDoctors();
  }

  return (
    <div className="site-shell">
      <div className="announcement">
        <span className="announcement-sparkle">✳</span>
        A healthier you starts with one small step.
        <a href="#how-it-works">Here’s how it works <Icon name="arrow" size={14} /></a>
      </div>

      <header className="site-header">
        <a className="brand" href="#home" aria-label="CarePlus home">
          <span className="brand-mark"><span>+</span></span>
          <span>care<span className="brand-light">plus</span></span>
        </a>
        <button
          className="menu-toggle"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <Icon name={menuOpen ? "close" : "menu"} />
        </button>
        <nav className={menuOpen ? "main-nav nav-open" : "main-nav"} aria-label="Main navigation">
          <a href="#doctors" onClick={() => setMenuOpen(false)}>Find a doctor</a>
          <a href="#specialties" onClick={() => setMenuOpen(false)}>Specialties</a>
          <a href="#how-it-works" onClick={() => setMenuOpen(false)}>How it works</a>
          <a href="#stories" onClick={() => setMenuOpen(false)}>Our patients</a>
          <button className="button button-primary header-book" onClick={() => openBooking()}>
            Book a visit <Icon name="arrow" size={17} />
          </button>
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <div className="trust-pill"><span className="trust-stars">★★★★★</span> Loved by 12,000+ patients</div>
            <h1>Good care.<br /><span>Good days.</span></h1>
            <p className="hero-description">
              Finding the right doctor shouldn’t be hard. Meet thoughtful,
              experienced care — on your time, and on your terms.
            </p>
            <form className="hero-search" onSubmit={handleSearch}>
              <label className="search-field">
                <Icon name="search" size={21} />
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  aria-label="Doctor or specialty"
                  placeholder="Doctor or specialty"
                />
              </label>
              <span className="search-divider" />
              <label className="search-field location-field">
                <Icon name="pin" size={21} />
                <select aria-label="Location" defaultValue="Brooklyn, NY">
                  <option>Brooklyn, NY</option>
                  <option>Manhattan, NY</option>
                  <option>Queens, NY</option>
                </select>
              </label>
              <button className="button button-primary search-button" type="submit" aria-label="Search doctors">
                <Icon name="search" size={19} /><span>Find care</span>
              </button>
            </form>
            <div className="hero-assurance">
              <span><Icon name="check" size={15} /> Same-week appointments</span>
              <span><Icon name="check" size={15} /> Insurance-friendly</span>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-photo">
              <img
                src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=1200&q=88"
                alt="A CarePlus doctor ready to help with your health"
              />
              <div className="photo-caption"><span className="caption-dot" /> Here for you, every step</div>
            </div>
            <div className="floating-card care-card">
              <div className="care-card-icon">✳</div>
              <div><strong>Care that feels different</strong><span>Personal, from day one</span></div>
            </div>
            <div className="floating-card rating-card">
              <div className="rating-avatars">
                <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=96&q=75" alt="" />
                <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=96&q=75" alt="" />
                <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=96&q=75" alt="" />
              </div>
              <div><strong>4.9 out of 5</strong><span>from real patient reviews</span></div>
            </div>
            <span className="hero-deco deco-one">✳</span>
            <span className="hero-deco deco-two">+</span>
          </div>
        </section>

        <section className="trust-strip" aria-label="CarePlus benefits">
          <div className="trust-item"><span className="trust-icon mint-icon">✳</span><span><strong>Care you can count on</strong><small>Vetted, board-certified doctors</small></span></div>
          <div className="trust-item"><span className="trust-icon peach-icon"><Icon name="clock" size={21} /></span><span><strong>Your time matters</strong><small>Book in minutes, not weeks</small></span></div>
          <div className="trust-item"><span className="trust-icon lilac-icon">♡</span><span><strong>People-first, always</strong><small>Real support at every step</small></span></div>
          <div className="trust-item"><span className="trust-icon yellow-icon"><Icon name="check" size={22} /></span><span><strong>No surprise bills</strong><small>Clear pricing before you book</small></span></div>
        </section>

        <section className="section specialties-section" id="specialties">
          <div className="section-heading">
            <div>
              <span className="eyebrow">CARE FOR EVERY YOU</span>
              <h2>What can we help with?</h2>
              <p>Whatever’s on your mind, there’s a specialist who gets it.</p>
            </div>
            <button className="text-link" onClick={() => showDoctors()}>Explore all doctors <Icon name="arrow" size={18} /></button>
          </div>
          <div className="specialty-grid">
            {specialties.map((specialty) => (
              <button
                className="specialty-card"
                key={specialty.name}
                onClick={() => showDoctors(specialtyDoctor[specialty.name])}
              >
                <span className={`specialty-icon ${specialty.color}`}>{specialty.icon}</span>
                <strong>{specialty.name}</strong>
                <small>{specialty.detail}</small>
                <span className="specialty-arrow"><Icon name="arrow" size={17} /></span>
              </button>
            ))}
          </div>
        </section>

        <section className="section doctors-section" id="doctors">
          <div className="section-heading doctors-heading">
            <div>
              <span className="eyebrow">GOOD PEOPLE. GREAT DOCTORS.</span>
              <h2>Meet your care team</h2>
              <p>Experts who listen first and make a plan that feels right for you.</p>
            </div>
            <div className="doctors-filter">
              <label className="sr-only" htmlFor="doctor-filter">Filter doctors by specialty</label>
              <select
                id="doctor-filter"
                value={selectedSpecialty}
                onChange={(event) => setSelectedSpecialty(event.target.value)}
              >
                <option>All doctors</option>
                <option>Cardiologist</option>
                <option>Neurologist</option>
                <option>Dermatologist</option>
                <option>Pediatrician</option>
                <option>Dentist</option>
                <option>Orthopedic</option>
              </select>
            </div>
          </div>
          {visibleDoctors.length ? (
            <div className="doctor-grid">
              {visibleDoctors.map((doctor) => (
                <article className="doctor-card" key={doctor.id}>
                  <div className={`doctor-image ${doctor.color}`}>
                    <img src={doctor.image} alt={doctor.name} loading="lazy" />
                    <span className="available-badge"><span /> Taking new patients</span>
                  </div>
                  <div className="doctor-info">
                    <div className="doctor-name-line">
                      <div><h3>{doctor.name}</h3><span>{doctor.specialty}</span></div>
                      <div className="doctor-rating"><Icon name="star" size={15} /> {doctor.rating}</div>
                    </div>
                    <div className="doctor-meta"><span>{doctor.experience}</span><span>{doctor.reviews}</span></div>
                    <div className="doctor-availability"><Icon name="clock" size={16} /><span>Next available: <strong>{doctor.available}</strong></span></div>
                    <div className="doctor-card-bottom">
                      <span className="doctor-fee">From <strong>{doctor.fee}</strong> <small>/ visit</small></span>
                      <button className="button button-outline" onClick={() => openBooking(doctor)}>
                        Book visit <Icon name="arrow" size={16} />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="empty-doctors">
              <span>✳</span>
              <h3>No matching doctors just yet</h3>
              <p>Try another name or specialty and we’ll help you find the right care.</p>
              <button className="text-link" onClick={() => { setSearch(""); setSelectedSpecialty("All doctors"); }}>
                See all doctors <Icon name="arrow" size={17} />
              </button>
            </div>
          )}
          <div className="all-doctors-link">
            <button className="button button-secondary" onClick={() => { setSearch(""); setSelectedSpecialty("All doctors"); }}>
              Meet all our doctors <Icon name="arrow" size={17} />
            </button>
          </div>
        </section>

        <section className="how-section" id="how-it-works">
          <div className="how-inner">
            <div className="how-copy">
              <span className="eyebrow">CARE, WITHOUT THE RUNAROUND</span>
              <h2>Getting care should feel easy. <span>So we made it.</span></h2>
              <p>Less time figuring things out. More time feeling like yourself.</p>
              <button className="button button-primary" onClick={() => openBooking()}>
                Find your doctor <Icon name="arrow" size={17} />
              </button>
            </div>
            <div className="steps">
              <article className="step-card">
                <span className="step-number">01</span>
                <div className="step-icon step-mint"><Icon name="search" size={22} /></div>
                <h3>Find your person</h3>
                <p>Browse caring, vetted doctors who fit your needs and your schedule.</p>
              </article>
              <article className="step-card">
                <span className="step-number">02</span>
                <div className="step-icon step-peach"><Icon name="calendar" size={22} /></div>
                <h3>Pick your moment</h3>
                <p>Choose an appointment that works for your life. No phone tag required.</p>
              </article>
              <article className="step-card">
                <span className="step-number">03</span>
                <div className="step-icon step-lilac">♡</div>
                <h3>Feel the difference</h3>
                <p>Get thoughtful, personal care from the very first hello.</p>
              </article>
            </div>
          </div>
        </section>

        <section className="section testimonial-section" id="stories">
          <div className="testimonial-visual">
            <img src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1000&q=85" alt="A patient sharing a warm moment with her care team" loading="lazy" />
            <div className="testimonial-photo-note">Care is better when it’s personal. <span>♡</span></div>
          </div>
          <div className="testimonial-copy">
            <span className="eyebrow">KIND WORDS, REAL PEOPLE</span>
            <div className="testimonial-stars" aria-label="5 out of 5 stars">★★★★★</div>
            <blockquote>“For the first time, I felt like I had a doctor in my corner — someone who actually listened. That changed everything.”</blockquote>
            <div className="testimonial-person">
              <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80" alt="" loading="lazy" />
              <div><strong>Sarah M.</strong><span>CarePlus patient since 2023</span></div>
            </div>
            <div className="testimonial-count"><strong>12,000+</strong><span>people finding a better kind of care</span></div>
          </div>
        </section>

        <section className="closing-cta">
          <div className="cta-flower flower-left">✳</div>
          <span className="eyebrow">YOUR NEXT CHAPTER STARTS HERE</span>
          <h2>A little care goes<br />a long way.</h2>
          <p>Let’s find the right doctor for you.</p>
          <button className="button button-white" onClick={() => openBooking()}>
            Book your first visit <Icon name="arrow" size={18} />
          </button>
          <div className="cta-flower flower-right">✳</div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-main">
          <div className="footer-brand">
            <a className="brand" href="#home">
              <span className="brand-mark"><span>+</span></span>
              <span>care<span className="brand-light">plus</span></span>
            </a>
            <p>Thoughtful care for all of life’s little and big moments.</p>
            <div className="api-indicator" data-state={apiStatus} role="status">
              <span /> {apiStatus === "connected" ? "CarePlus care team online" : apiStatus === "checking" ? "Connecting to CarePlus…" : "CarePlus care team"}
            </div>
          </div>
          <div className="footer-links">
            <div><strong>Explore</strong><a href="#doctors">Find a doctor</a><a href="#specialties">Specialties</a><a href="#how-it-works">How it works</a></div>
            <div><strong>CarePlus</strong><a href="#stories">Our story</a><a href="#stories">Patient stories</a><a href="mailto:hello@careplus.example">Contact us</a></div>
            <div><strong>Need a hand?</strong><a href="tel:+18005550142"><Icon name="phone" size={15} /> (800) 555-0142</a><span>Mon–Fri, 8am–6pm</span></div>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2025 CarePlus Health. Made with care.</span>
          <span>Privacy · Terms · Accessibility</span>
        </div>
      </footer>

      {bookingOpen && (
        <AppointmentModal doctor={bookingDoctor} onClose={closeBooking} />
      )}
      {!bookingOpen && (
        <button className="floating-book" onClick={() => openBooking()} aria-label="Book an appointment">
          Book a visit <Icon name="arrow" size={17} />
        </button>
      )}
    </div>
  );
}
